﻿using System;
using System.Collections.Generic;
using System.Text;
using capa02_Logica;
using CapaEntidades;

namespace Capas_Practica
{
    internal class Configuracion
    {
        public static string getConnectionString
        {
            get
            {
                return Properties.Settings.Default.connectiondDb;
            }
        }
       
    }
}
