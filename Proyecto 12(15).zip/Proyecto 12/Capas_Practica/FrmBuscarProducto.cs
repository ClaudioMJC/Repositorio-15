﻿using capa02_Logica;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capas_Practica
{
    public partial class FrmBuscarProducto : Form
    {
        public FrmBuscarProducto()
        {
            InitializeComponent();
        }

        public event EventHandler Aceptar;
        int vgn_id_producto;
        //fin


        //paso 6 presentación 21
        public void CargarListaProductos(string condicion = "")
        {
            Bl_Productos logicaBuscar = new Bl_Productos(Configuracion.getConnectionString);
            List<Productos> listarProductos;
            try
            {
                listarProductos = logicaBuscar.llamarListaProductos(condicion);
                if (listarProductos.Count > 0)
                {
                    dataGridView1.DataSource = listarProductos;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //PASO NÚMERO 7 PRESENTACIÓN 21
        private void FrmBuscarProducto_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaProductos();
                //en el load se llama a cargar el gridview con el data set

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Paso número 8 presentación 21
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtNombre.Text))
                {
                    //lo que escriba en el txtNombre, el Trim le quita los espacios en blanco
                    condicion = string.Format("DESCRIPCION like '%{0}%'", txtNombre.Text.Trim());

                }
                else
                {
                    MessageBox.Show("Debe escribir parte del nombre a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNombre.Focus();
                }
                CargarListaProductos(condicion);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //PASO 13 PRESENTACIÓN 21
        
         
        private void seleccionar()
        {
            /*if (grdListaPacientes.SelectedRows.Count > 0)
            {
                global_id_paciente = (int)grdListaPacientes.SelectedRows[0].Cells[0].Value;
                Aceptar(global_id_paciente, null);
                Close();
            }
            */
            string nombreColumna = "ID_PRODUCTO"; //directamente se accede al índice de la columna con el nombre "ID_PACIENTE" 
            int indiceColumna = dataGridView1.Columns[nombreColumna].Index;
            DataGridViewCell cell = dataGridView1.SelectedRows[0].Cells[indiceColumna];
            if (cell != null && cell.Value != null)
            {

                vgn_id_producto = (int)cell.Value;
                Aceptar(vgn_id_producto, null);
                Close();
            }




        }



        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            seleccionar();
        }
        //FIN PASO 13

        //FIN PASO 14
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }
        //FIN 14

    }//public partial class end


}

