﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using capa02_Logica;
using CapaEntidades;

namespace Capas_Practica
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmClientes menuCliente = new FrmClientes();
            menuCliente.MdiParent = this;
            menuCliente.Show();


        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProductos menuProductos = new FrmProductos();
            menuProductos.MdiParent = this;
            menuProductos.Show();
        }

        private void facturaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFacturacion menuFacturacion = new FrmFacturacion();
            menuFacturacion.MdiParent = this;
            menuFacturacion.Show();
        }

        /*
        private void encabezadoDeFacturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            encabezadoFactura menuEncabezadoFactura = new encabezadoFactura();
            menuEncabezadoFactura.MdiParent = this;
            menuEncabezadoFactura.Show();
        }
        */
    }  
}
