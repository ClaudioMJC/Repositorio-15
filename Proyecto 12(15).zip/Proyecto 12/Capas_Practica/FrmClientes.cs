﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using capa02_Logica;
using Capa03_AccesoDatos;
using CapaEntidades;


namespace Capas_Practica
{

    public partial class FrmClientes : Form
    {   //PASO NÚMERO 9 PRESENTACIÓN 21
        FrmBuscarC formularioBuscar;
        //PASO 9 FIN
        //11 presentación 21
        Clientes clienteRegistrado;
        public FrmClientes()
        {
            InitializeComponent();
        }

        //crea un objeto con los datos ingresados en las casillas de texto
        public Clientes generaCliente()
        {   
            Clientes Uncliente;
            if (!string.IsNullOrEmpty(txtIdCliente.Text))
            {
                Uncliente = clienteRegistrado;
            }
            else
            {
                Uncliente = new Clientes();
            }
            Uncliente.Nombre=(txtNombre.Text);
           
            Uncliente.Direccion = (txtNombre.Text);
            Uncliente.Telefono = (txtTelefono.Text);
            Uncliente.Direccion = (txtDireccion.Text);
            return Uncliente;

            
        }//fin genera ent
        
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Clientes UnCliente = generaCliente();
            Bl_Clientes logicaCliente = new Bl_Clientes(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtNombre.Text) || string.IsNullOrEmpty(txtTelefono.Text) || string.IsNullOrEmpty(txtDireccion.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (UnCliente.Existe)
                    {
                        resultado = logicaCliente.Modificar(UnCliente);
                        if (resultado > 0)
                        {
                            LimpiarCasillas();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaClientes();
                        }
                        else
                        {
                            MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        resultado = logicaCliente.LlamarMetodoInsertar(UnCliente);
                        if (resultado > 0)
                        {
                            LimpiarCasillas();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaClientes();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo guardar el cliente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }
        
        public void LimpiarCasillas()
        {
            txtIdCliente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtNombre.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        //paso 4 presentación 21
        private void FrmClientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //paso 5 presentación 21  //SE CONFIGURA EL BOTON DE MANERA DIFERENTE EN AMBOS PASOS
        //PASA 10 PRESENTACION 21
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //FrmBuscarClientes frm = new FrmBuscarClientes();
            //frm.Show();
            formularioBuscar = new FrmBuscarC();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        } //fin_btnBuscar_Click


        //Cargar los datos  presentacion 21 tercer paso
        public void CargarListaClientes(string condicion = "")
        {
            Bl_Clientes logicaBuscar = new Bl_Clientes(Configuracion.getConnectionString);
            List<Clientes> listarClientes;
            try
            {
                listarClientes = logicaBuscar.llamarListaClientes(condicion);
                if (listarClientes.Count > 0)
                {
                    grdClientes.DataSource = listarClientes;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //paso 11 presentación 21
        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idCliente = (int)id;
                if (idCliente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    CargarClientes(idCliente);
                }
                else
                {
                    LimpiarCasillas();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar

        //Paso 17 presentación 21
        private void CargarClientes(int id)
        {
            Clientes cliente = new Clientes();
            Bl_Clientes traerCliente = new Bl_Clientes(Configuracion.getConnectionString);
            try
            {
                cliente = traerCliente.obtenerCliente(id);
                if (cliente != null)
                {
                    txtIdCliente.Text = cliente.Id_Cliente.ToString();
                    txtNombre.Text = cliente.Nombre;
                    txtTelefono.Text = cliente.Telefono;
                    txtDireccion.Text = cliente.Direccion;
                    clienteRegistrado = cliente;
                }
                else
                {
                    MessageBox.Show("El cliente no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCasillas();
        }

        //paso 4 presentación 22
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Clientes cliente;
            int resultado;
            Bl_Clientes logica = new Bl_Clientes(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdCliente.Text))
                {
                    cliente = logica.obtenerCliente(int.Parse(txtIdCliente.Text));
                    if (cliente != null)
                    {   /*
                        resultado = logica.EliminarConSP(cliente);
                        MessageBox.Show(logica.Mensaje, "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        */
                        resultado = logica.EliminarCliente (cliente);
                        MessageBox.Show("Eliminado sin SP", "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        LimpiarCasillas();
                        CargarListaClientes();


                    }
                    else
                    {
                        MessageBox.Show("El cliente no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCasillas();
                        CargarListaClientes();
                    }
                }
                else
                {
                    MessageBox.Show("Debe Seleccionar un cliente antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        } //btn Eliminar

        //paso 7 presentación 22
        
        



    }//public partial class end
}
