﻿namespace Capas_Practica
{
    partial class FrmBuscarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarProducto));
            btnCancelar = new System.Windows.Forms.Button();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            txtNombre = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            dataGridView1 = new System.Windows.Forms.DataGridView();
            ID_PRODUCTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DESCRIPCIÓN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOCOMPRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOVENTA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            GRAVADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnCancelar.Location = new System.Drawing.Point(491, 315);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(111, 110);
            btnCancelar.TabIndex = 35;
            btnCancelar.Text = "Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(674, 25);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 110);
            btnBuscar.TabIndex = 34;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnAceptar.Location = new System.Drawing.Point(640, 315);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(111, 110);
            btnAceptar.TabIndex = 33;
            btnAceptar.Text = " &Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(177, 70);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(471, 31);
            txtNombre.TabIndex = 31;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(15, 70);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(156, 25);
            label1.TabIndex = 30;
            label1.Text = "Nombre Producto";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_PRODUCTO, DESCRIPCIÓN, PRECIOCOMPRA, PRECIOVENTA, GRAVADO });
            dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Location = new System.Drawing.Point(-3, 154);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new System.Drawing.Size(807, 142);
            dataGridView1.TabIndex = 59;
            dataGridView1.DoubleClick += dataGridView1_DoubleClick;
            // 
            // ID_PRODUCTO
            // 
            ID_PRODUCTO.DataPropertyName = "ID_PRODUCTO";
            ID_PRODUCTO.HeaderText = "ID_PRODUCTO";
            ID_PRODUCTO.MinimumWidth = 8;
            ID_PRODUCTO.Name = "ID_PRODUCTO";
            ID_PRODUCTO.Width = 150;
            // 
            // DESCRIPCIÓN
            // 
            DESCRIPCIÓN.DataPropertyName = "DESCRIPCION";
            DESCRIPCIÓN.HeaderText = "DESCRIPCIÓN";
            DESCRIPCIÓN.MinimumWidth = 8;
            DESCRIPCIÓN.Name = "DESCRIPCIÓN";
            DESCRIPCIÓN.Width = 150;
            // 
            // PRECIOCOMPRA
            // 
            PRECIOCOMPRA.DataPropertyName = "PRECIOCOMPRA";
            PRECIOCOMPRA.HeaderText = "PRECIO DE COMPRA";
            PRECIOCOMPRA.MinimumWidth = 8;
            PRECIOCOMPRA.Name = "PRECIOCOMPRA";
            PRECIOCOMPRA.Width = 150;
            // 
            // PRECIOVENTA
            // 
            PRECIOVENTA.DataPropertyName = "PRECIOVENTA";
            PRECIOVENTA.HeaderText = "PRECIO DE VENTA";
            PRECIOVENTA.MinimumWidth = 8;
            PRECIOVENTA.Name = "PRECIOVENTA";
            PRECIOVENTA.Width = 150;
            // 
            // GRAVADO
            // 
            GRAVADO.DataPropertyName = "GRAVADO";
            GRAVADO.HeaderText = "GRAVADO";
            GRAVADO.MinimumWidth = 8;
            GRAVADO.Name = "GRAVADO";
            GRAVADO.Width = 150;
            // 
            // FrmBuscarProducto
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(btnCancelar);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(txtNombre);
            Controls.Add(label1);
            Name = "FrmBuscarProducto";
            Text = "FrmBuscarProducto";
            Load += FrmBuscarProducto_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PRODUCTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DESCRIPCIÓN;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOCOMPRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOVENTA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GRAVADO;
    }
}