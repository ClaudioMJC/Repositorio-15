﻿using capa02_Logica;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capas_Practica
{
    public partial class FrmBuscarC : Form
    {
        //Paso número 12 presentación 21
        public event EventHandler Aceptar;
        int vgn_id_cliente;
        //fin
        public FrmBuscarC()
        {
            InitializeComponent();
        }

        //paso 6 presentación 21
        public void CargarListaClientes(string condicion = "")
        {
            Bl_Clientes logicaBuscar = new Bl_Clientes(Configuracion.getConnectionString);
            List<Clientes> listarClientes;
            try
            {
                listarClientes = logicaBuscar.llamarListaClientes(condicion);
                if (listarClientes.Count > 0)
                {
                    grdClientes.DataSource = listarClientes;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //PASO NÚMERO 7 PRESENTACIÓN 21
        private void FrmBuscarC_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaClientes();
                //en el load se llama a cargar el gridview con el data set

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

        }

        //Paso número 8 presentación 21
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtNombre.Text))
                {
                    //lo que escriba en el txtNombre, el Trim le quita los espacios en blanco
                    condicion = string.Format("Nombre like '%{0}%'", txtNombre.Text.Trim());

                }
                else
                {
                    MessageBox.Show("Debe escribir parte del nombre a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNombre.Focus();
                }
                CargarListaClientes(condicion);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //PASO 13 PRESENTACIÓN 21
        private void seleccionar()
        {
            if (grdClientes.SelectedRows.Count > 0)
            {
                vgn_id_cliente = (int)grdClientes.SelectedRows[0].Cells[0].Value;
                Aceptar(vgn_id_cliente, null);
                Close();
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();
        }

        //presentación 22 paso 1 
        private void grdClientes_DoubleClick(object sender, EventArgs e)
        {
            //seleccionar();
            int id = 0;
            try
            {
                id = (int)grdClientes.SelectedRows[0].Cells[0].Value;
                CargarListaClientes(id.ToString());
                


            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }              
        }
        //FIN PASO 13

        //FIN PASO 14
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }
        //FIN 14

    }//public partial class end


}

