﻿using System;
using System.Data.SqlClient;
using CapaEntidades;
using System.Linq;
using System.Data;
using System.Collections.Generic;
using System.Data.Common;

namespace Capa03_AccesoDatos
{
    public class DaProductos
    {       //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DaProductos(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int Insertar(Productos producto)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO PRODUCTOS (DESCRIPCION, PRECIOCOMPRA,PRECIOVENTA,GRAVADO)"+
            "VALUES( @DESCRIPCION, @PRECIOCOMPRA, @PRECIOVENTA, @GRAVADO) SELECT SCOPE_IDENTITY()";
            comando.Parameters.AddWithValue("@DESCRIPCION", producto.Descripcion);
            comando.Parameters.AddWithValue("@PRECIOCOMPRA", producto.Precio_Compra);
            comando.Parameters.AddWithValue("@PRECIOVENTA", producto.Precio_Venta);
            comando.Parameters.AddWithValue("@GRAVADO", producto.Gravado);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar


        public List<Productos> ListaProductos(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<Productos> listaProductos;

            string instruccionDB = "SELECT ID_PRODUCTO, DESCRIPCION, PRECIOCOMPRA,PRECIOVENTA,GRAVADO FROM PRODUCTOS";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "PRODUCTOS");
                listaProductos = (from DataRow unaFila in elDataSet.Tables["PRODUCTOS"].Rows
                                  select new Productos()
                                  {

                                      Id_Producto = (int)unaFila[0],
                                      Descripcion = unaFila[1].ToString(),
                                      //Precio_Compra = float.TryParse(unaFila[2].ToString(), //out float precioCompra) ? precioCompra : 0.0f,
                                      //Precio_Venta = float.TryParse(unaFila[3].ToString(), //out float precioVenta) ? precioVenta : 0.0f,
                                      Precio_Compra = Convert.ToSingle(unaFila[2]),
                                      Precio_Venta = Convert.ToSingle(unaFila[3]),
                                      Gravado = unaFila[4].ToString(),


                                  }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaProductos;

        }


        public Productos ObtenerProducto(int id)
        {
            Productos productos = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_PRODUCTO, DESCRIPCION, PRECIOCOMPRA,PRECIOVENTA,GRAVADO FROM " +
                "PRODUCTOS WHERE ID_PRODUCTO = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    productos = new Productos();
                    dataReader.Read();
                    productos.Id_Producto = dataReader.GetInt32(0);
                    productos.Descripcion = dataReader.GetString(1);
                    productos.Precio_Compra = Convert.ToSingle(dataReader.GetDouble(2));
                    productos.Precio_Venta = Convert.ToSingle(dataReader.GetDouble(3));
                    productos.Gravado = dataReader.GetString(4);
                    //productos.Precio_Compra = dataReader.GetFloat(2);
                    //productos.Precio_Venta = dataReader.GetFloat(3);


                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return productos;
        }  //fin obtener cliente 

        //este metodo sirve para eliminar un cliente pero sin llamar a un SP
        public int EliminarCliente(Productos producto)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM PRODUCTOS";
            sentencia = string.Format("{0} WHERE ID_PRODUCTO ={1}", sentencia, producto.Id_Producto);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception) { throw; }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }

        public int Modificar(Productos producto)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE PRODUCTOS SET DESCRIPCION=@DESCRIPCION,PRECIOCOMPRA=@PRECIOCOMPRA,PRECIOVENTA=@PRECIOVENTA,GRAVADO=@GRAVADO WHERE ID_PRODUCTO=@ID_PRODUCTO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_PRODUCTO", producto.Id_Producto);
            comando.Parameters.AddWithValue("@DESCRIPCION", producto.Descripcion);
            comando.Parameters.AddWithValue("@PRECIOCOMPRA", producto.Precio_Compra);
            comando.Parameters.AddWithValue("@PRECIOVENTA", producto.Precio_Venta);
            comando.Parameters.AddWithValue("@GRAVADO", producto.Gravado);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception) { throw; }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;

        }//fin modificar




    }
}
