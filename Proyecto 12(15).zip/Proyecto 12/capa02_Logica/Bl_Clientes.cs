﻿using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using CapaEntidades;

namespace capa02_Logica
{
    public class Bl_Clientes
    {
        //atributos  N°3      
        private string _cadenaConexion;
        private string _mensaje;

        //propiedades
        public string Mensaje
        {
            get => _mensaje;
        }

        // constructor
        public Bl_Clientes(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        //metodo para llamar al metodo insertar de la capa3accesodatos N°4
        public int LlamarMetodoInsertar(Clientes cliente)
        {
            int id_cliente = 0;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                id_cliente = accesoDatos.Insertar(cliente);
            }
            catch (Exception)
            {
                throw;
            }
            return id_cliente;
        }// fin de la clase insertar

        //presentación 21 segundo paso
        //metodo para llamarlistar
        public List<Clientes> llamarListaClientes(string condicion = "")
        {
            List<Clientes> listaClientes;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                listaClientes = accesoDatos.ListaClientes(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaClientes;
        }

        //paso 16 presentación 21

        public Clientes obtenerCliente(int id)
        {
            Clientes cliente;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                cliente = accesoDatos.ObtenerCliente(id);
            }
            catch (Exception)
            {
                throw;
            }
            return cliente;
        }//Obtenerfin paso 16

        //presentación 22 paso 3 
        public int EliminarConSP(Clientes cliente)
        {
            int resultado;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarRegistroConSP(cliente);
                _mensaje = accesoDatos.Mensaje;

            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }

        //paso 6 presentación 22
        public int EliminarCliente(Clientes cliente)
        {
            int resultado;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarCliente(cliente);

            }
            catch (Exception)
            {
                throw;
            }
            return resultado;

        }//Eliminar cliente


        //paso 11 presentación 21

        public int Modificar(Clientes cliente)
        {
            int filasAfectadas = 0;
            DACliente accesoDatos = new DACliente(_cadenaConexion);

            try
            {
                filasAfectadas = accesoDatos.Modificar(cliente);
            }
            catch(Exception)
            {
                throw;
            }
            return filasAfectadas;

        }


    }//Bl cliente
}
